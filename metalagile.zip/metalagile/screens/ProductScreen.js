import React, { useState } from 'react';
import { View, Text, TextInput, Image, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';

// Importar imagens locais
const productImages = {
  '1': require('../assets/metalagile/canos.jpg'),
  '2': require('../assets/metalagile/engrenagens.jpg'),
  '3': require('../assets/metalagile/porcas_parafusos.jpg'),
  '4': require('../assets/metalagile/barras_metal.jpg'),
  // Adicione mais produtos conforme necessário
};

const logo = require('../assets/metalagile/logo.jpg'); 
// Caminho correto para a imagem do logo

const products = [
  { id: '1', name: 'Canos de metal (x1)', price: 55, image: productImages['1'] },
  { id: '2', name: 'Engrenagens (x5)', price: 30, image: productImages['2'] },
  { id: '3', name: 'Porcas e Parafusos (x20)', price: 20, image: productImages['3'] },
  { id: '4', name: 'Barras de metal (x1)', price: 70, image: productImages['4'] },
  // Adicione mais produtos conforme necessário
];

const ProductScreen = ({ navigation }) => {
  const [cart, setCart] = useState([]);
  const [quantities, setQuantities] = useState({});

  const handleAddToCart = (product) => {
    const quantity = quantities[product.id] || 1;
    setCart([...cart, { ...product, quantity }]);
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Image source={logo} style={styles.logo} />
          <Text style={styles.title}>Escolha seu produto</Text>
        </View>

        {products.map((product) => (
          <View key={product.id} style={styles.product}>
            <Image source={product.image} style={styles.image} />
            <View style={styles.details}>
              <Text style={styles.name}>{product.name}</Text>
              <Text style={styles.price}>R$ {product.price.toFixed(2)}</Text>
              <TextInput
                placeholder="Quantidade"
                keyboardType="numeric"
                value={quantities[product.id]?.toString() || ''}
                onChangeText={(text) => setQuantities((prev) => ({
                  ...prev,
                  [product.id]: parseInt(text) || 1,
                }))}
                style={styles.input}
              />
              <TouchableOpacity style={styles.button} onPress={() => handleAddToCart(product)}>
                <Text style={styles.buttonText}>Adicionar ao Carrinho</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
      <View style={styles.checkoutButton}>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Checkout', { cart })}>
          <Text style={styles.buttonText}>Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#C0C0C0',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 75,
    height: 75,
    marginRight: 10,
    borderRadius: 100,
  },
  title: {
    fontSize: 24,
    flex: 1,
  },
  product: {
    flexDirection: 'row',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    padding: 10,
    backgroundColor: '#4B4B4B',
  },
  image: {
    width: 100,
    height: 100,
    marginRight: 20,
  },
  details: {
    flex: 1,
    justifyContent: 'center',
  },
  name: {
    fontSize: 18,
    marginBottom: 10,
    color: '#fff'
  },
  price: {
    fontSize: 16,
    marginBottom: 10,
    color: '#fff'
  },
  input: {
    borderWidth: 1,
    borderColor: '#606060',
    borderRadius: 5,
    padding: 5,
    width: 100,
    marginBottom: 10,
    textAlign: 'center',
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#606060',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  checkoutButton: {
    padding: 20,
    borderTopWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#808080',
  },
});

export default ProductScreen;